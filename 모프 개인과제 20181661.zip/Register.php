<?php 
    $con = mysqli_connect("localhost", "tndus9477", "tndus1011!", "tndus9477");
    mysqli_query($con,'SET NAMES utf8');

    $userID = $_POST["userID"];
    $userPassword = $_POST["userPassword"];
    $userName = $_POST["userName"];
    $userAge = $_POST["userAge"];
    $userAdr = $_POST["userAdr"];

    $statement = mysqli_prepare($con, "INSERT INTO USERS VALUES (?,?,?,?,?)");
    mysqli_stmt_bind_param($statement, "sssis", $userID, $userPassword, $userName, $userAge, $userAdr);
    mysqli_stmt_execute($statement);


    $response = array();
    $response["success"] = true;
 
   
    echo json_encode($response);



?>